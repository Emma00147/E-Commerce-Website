var navlinks= document.getElementById('nav-links');
function openMenu() {

	navlinks.style.right= "0";

}
function closeMenu(){
	navlinks.style.right ="-250px";
}